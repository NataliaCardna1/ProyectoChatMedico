package modelo;

public class Manejador {

}
