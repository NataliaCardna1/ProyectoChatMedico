package modelo;

public enum TipoDocumento {
    RADIOGRAFIAS,
    INFORME_LABORATORIO,
    HISTORIAS_CLINICAS,
    RECETAS_MEDICAS,
    OTROS,
}
