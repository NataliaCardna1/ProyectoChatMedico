package modelo;

import java.time.LocalDateTime;

public class Mensaje {
    private String texto;
    private LocalDateTime fecha;
    private Usuario remitente;
}
